$(function() {
    // Get the form.
    var form = $('#reviewsubmit');

    // Get the messages div.
    var formMessages = $('#form-messages');

    // TODO: The rest of the code will go here...


    /* prevent submission */
	$(form).submit(function(event) {
	    // Stop the browser from submitting the form.
	    event.preventDefault();

	    // TODO
	});
});
