<?php
$dbURL="localhost";
$dbName="student";
$dbusername="root";
$dbpassword="database";
$dbdetails=array(
    'url'=>$dbURL,
    'name'=>$dbName,
    'username'=>$dbusername,
    'password'=>$dbpassword
);

?>
